create trigger INS_COMM
    before insert
    on SALESPEOPLE
    for each row
BEGIN
:NEW.comm:=:NEW.comm *11;
END;
/

