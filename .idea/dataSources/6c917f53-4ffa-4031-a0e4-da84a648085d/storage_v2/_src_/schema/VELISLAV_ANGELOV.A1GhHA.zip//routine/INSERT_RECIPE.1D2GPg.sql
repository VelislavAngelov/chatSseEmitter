create PROCEDURE Insert_Recipe(
   Dish   varchar,
   Prod   varchar,
   Quan   varchar) AS
BEGIN
   INSERT INTO Recipe 
   SELECT d.DishesID, p.ProductID, Quan FROM Dishes d, Product p WHERE d.DishName LIKE Dish AND p.Name LIKE Prod;
END;
/

