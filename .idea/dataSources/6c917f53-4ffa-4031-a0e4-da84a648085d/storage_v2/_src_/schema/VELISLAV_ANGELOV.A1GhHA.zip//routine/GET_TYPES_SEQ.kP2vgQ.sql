create FUNCTION get_types_seq RETURN NUMBER IS
BEGIN
RETURN Types_seq.nextval;
END;
/

