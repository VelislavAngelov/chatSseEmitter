create PROCEDURE insert_cust_hristina2 AS
BEGIN
INSERT into employee(employee_id,firstname,dept,salary,location)
VALUES(3,'hristina552','softwere',4333,'Burgas');

END;
/

