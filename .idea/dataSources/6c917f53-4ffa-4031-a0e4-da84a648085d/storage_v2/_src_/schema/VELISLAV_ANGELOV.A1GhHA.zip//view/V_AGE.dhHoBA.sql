create view V_AGE as
SELECT CustomerID,
LastName,FirsName,Age FROM customers WHERE city='London'
/

