create PROCEDURE insert_Productnew
   (
   product varchar,
   type varchar,
   grams int, 
   calories int,
   price NUMBER) as
   begin
   insert INTO productnew
   select null, product, product_type.product_type_id, grams, calories, price from product_type where product_type.product_name like type;
   end;
/

