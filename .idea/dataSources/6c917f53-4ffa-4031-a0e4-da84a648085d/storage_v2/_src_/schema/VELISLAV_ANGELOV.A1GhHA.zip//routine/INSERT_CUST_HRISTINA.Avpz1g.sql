create PROCEDURE insert_cust_hristina(id2 int,age2 int)AS
BEGIN
INSERT INTO employee(employee_id,firstname,dept,salary,location)
VALUES (2,'hristina55','softwere',3333,'Burgas');
END;
/

