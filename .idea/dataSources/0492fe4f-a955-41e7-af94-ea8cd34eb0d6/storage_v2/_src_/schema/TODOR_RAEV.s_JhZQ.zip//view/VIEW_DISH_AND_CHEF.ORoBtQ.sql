create view VIEW_DISH_AND_CHEF as
SELECT dn.dish_id,dt.dish_type,dn.dish_name,ch.chef_name 
    FROM dish_name dn 
    RIGHT JOIN dish_type dt 
    ON dn.dish_type_id =dt.dish_type_id
    RIGHT JOIN chef ch 
    ON dn.chef_id = ch.chef_id
/

