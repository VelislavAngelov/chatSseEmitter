create trigger PRODUCT_TYPE_ID_INCREMENT
    before insert
    on PRODUCT_TYPE
    for each row
BEGIN 
    SELECT seq_Product_Type.nextval INTO:NEW.Product_Type_Id FROM dual;
    END;
/

