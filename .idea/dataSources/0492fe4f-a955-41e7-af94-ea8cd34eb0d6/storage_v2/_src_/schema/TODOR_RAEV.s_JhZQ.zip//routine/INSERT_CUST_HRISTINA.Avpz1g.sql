create procedure insert_cust_hristina (id2 int, age2 int) AS 
begin
    insert into customers2(customerid, firstname, age, city, salary)
    values (id2, 'hristina55', age2, 'burgas', 3333);
end;
/

