create view V_UNION as
(select firstname, lastname, department, comm 
        from v_people 
        where city = 'Mexico')
        
    union
    
   (select firstname, lastname, department, comm 
        from v_people 
        where comm > 0.13)
/

