create PROCEDURE update_course_lecturer(pk_id in int, lecturer in varchar2) AS
BEGIN
    update COURSES2  
    set COURSES2.LECTURER=update_course_lecturer.lecturer 
    where COURSES2.PK_ID = update_course_lecturer.pk_id ;
END;
/

