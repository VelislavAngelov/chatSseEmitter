create view VIEW_RECEPIES as
SELECT vdc.dish_type,vdc.dish_name,vdc.chef_name,r.units,vp.product_name,vp.product_unit_grams,vp.product_calories,vp.product_price 
    FROM Recipes r INNER JOIN view_dish_and_chef vdc 
    ON r.dish_id = vdc.dish_id INNER JOIN view_products vp 
    ON r.product_id = vp.product_id
    ORDER BY vdc.dish_type, vdc.dish_name
/

