create view V_SUBQUERY as
select firstname, lastname, city, department 
from customers 
where lastname IN (select sname 
                    from salespeople
                    where comm > 0.08)
/

