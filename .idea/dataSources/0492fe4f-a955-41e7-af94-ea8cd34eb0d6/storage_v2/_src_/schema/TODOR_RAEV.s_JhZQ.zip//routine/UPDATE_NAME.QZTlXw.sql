create PROCEDURE update_name(pk_id in int, name in varchar2) AS
BEGIN
    update STUDENTS2
    set STUDENTS2.name=update_name.name
    where STUDENTS2.PK_ID = update_name.pk_id ;
END;
/

