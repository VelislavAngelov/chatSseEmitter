create trigger INS_COMM
    before insert
    on SALESPEOPLE
    for each row
begin 
            :new.comm := :new.comm*11;
        end;
/

