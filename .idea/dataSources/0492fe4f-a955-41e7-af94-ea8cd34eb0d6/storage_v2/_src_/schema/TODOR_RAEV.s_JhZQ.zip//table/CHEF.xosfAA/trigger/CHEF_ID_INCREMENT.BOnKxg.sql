create trigger CHEF_ID_INCREMENT
    before insert
    on CHEF
    for each row
BEGIN 
    SELECT seq_Chef.nextval INTO:NEW.chef_id FROM dual;
    END;
/

