create trigger DISH_ID_INCREMENT
    before insert
    on DISH_NAME
    for each row
BEGIN 
    SELECT seq_Dish_Name.nextval INTO:NEW.Dish_Id FROM dual;
    END;
/

