create view V_COMM as
select firstname, lastname, department 
    from v_people 
    where comm > 0.05
/

