create PROCEDURE update_all_student_details (pk_id in int,name in varchar2, grade in int) AS
BEGIN
    update_name(pk_id,name);
    update_grade(pk_id,grade);
END;
/

