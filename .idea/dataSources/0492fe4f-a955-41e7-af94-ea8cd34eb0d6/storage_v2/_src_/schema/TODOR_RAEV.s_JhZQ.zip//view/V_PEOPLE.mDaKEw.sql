create view V_PEOPLE as
select c.firstname, c.lastname, c.city, c.department, s.city as region, s.comm 
    from customers c join Salespeople s
    on c.lastname = s.sname
/

