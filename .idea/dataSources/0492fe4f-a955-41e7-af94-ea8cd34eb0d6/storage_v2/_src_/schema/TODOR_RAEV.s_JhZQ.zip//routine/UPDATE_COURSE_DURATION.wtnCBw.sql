create PROCEDURE update_course_duration(pk_id in int, duration in int) AS
BEGIN
    update COURSES2  
    set COURSES2.DURATION=update_course_duration.duration 
    where COURSES2.PK_ID = update_course_duration.pk_id ;
END;
/

