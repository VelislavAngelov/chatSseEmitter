create trigger DISH_TYPE_ID_INCREMENT
    before insert
    on DISH_TYPE
    for each row
BEGIN 
    SELECT seq_Dish_Type.nextval INTO:NEW.Dish_Type_Id FROM dual;
    END;
/

