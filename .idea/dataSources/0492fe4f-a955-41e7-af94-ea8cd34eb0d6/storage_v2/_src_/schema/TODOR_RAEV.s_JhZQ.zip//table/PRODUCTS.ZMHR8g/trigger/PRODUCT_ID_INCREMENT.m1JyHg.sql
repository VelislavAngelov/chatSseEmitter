create trigger PRODUCT_ID_INCREMENT
    before insert
    on PRODUCTS
    for each row
BEGIN 
    SELECT seq_Products.nextval INTO:NEW.Product_Id FROM dual;
    END;
/

