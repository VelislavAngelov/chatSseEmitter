create view FULL_LIST as
select s."STUDENTID",s."FIRSTNAME",s."LASTNAME",s."BIRTHDATE",s."CITY",s."COUNTRY", coalesce(c.course, 'N/A') as course,  d.startdate, d.enddate, round(months_between (d.enddate, d.startdate)) as months_between
from students s left join dataCourses d on d.studentid = s.studentid 
left join courses c on d.courseid = c.courseid
/

