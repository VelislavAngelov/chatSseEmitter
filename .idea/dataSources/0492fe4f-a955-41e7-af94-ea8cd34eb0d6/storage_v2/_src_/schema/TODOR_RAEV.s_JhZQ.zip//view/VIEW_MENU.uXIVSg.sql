create view VIEW_MENU as
SELECT vr.dish_name,vr.chef_name,
        SUM(vr.units*vr.product_calories)|| ' cal.'Energy,
        SUM(vr.units*vr.product_unit_grams) || ' gr.' Weight,
        ROUND(SUM(vr.product_price*vr.units*1.35),2) ||' lv.' Price 
    FROM view_recepies vr
    GROUP BY vr.dish_name,vr.chef_name
/

