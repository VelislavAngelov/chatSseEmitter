create function get_types_seq return number is 
begin
    return types_seq.nextval;
end;
/

