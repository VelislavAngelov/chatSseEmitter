create view VIEW_PRODUCTS as
SELECT pr.product_id,pr.product_name,pr.product_unit_grams,pr.product_calories,pr.product_price 
    FROM product_type pt LEFT JOIN products pr 
    ON pt.product_type_id = pr.product_type_id
/

