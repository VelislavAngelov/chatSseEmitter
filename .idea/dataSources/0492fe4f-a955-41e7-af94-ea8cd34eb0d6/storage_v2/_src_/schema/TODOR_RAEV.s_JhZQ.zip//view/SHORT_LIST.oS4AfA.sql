create view SHORT_LIST as
select s.firstname, s.lastname, s.birthdate, count(d.studentid) as count_courses
from students s, datacourses d
where s.studentid = d.studentid
group by d.studentid, s.firstname, s.lastname, s.birthdate
/

