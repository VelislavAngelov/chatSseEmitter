create PROCEDURE update_course_name(pk_id in int, name in varchar2) AS
BEGIN
    update COURSES2  
    set COURSES2.name=update_course_name.name 
    where COURSES2.PK_ID = update_course_name.pk_id ;
END;
/

