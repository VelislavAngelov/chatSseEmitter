create PROCEDURE update_order(ID1 int, amount1 FLOAT) AS 
BEGIN 
    insert into orders2_copy 
    select o_id, o_date, customerid, amount, sysdate, (select max(id)+ 1 from orders2_copy)
        from orders2 
        where o_id = id1;

    update orders2 set amount = amount1
        where o_id = id1;
END;
/

