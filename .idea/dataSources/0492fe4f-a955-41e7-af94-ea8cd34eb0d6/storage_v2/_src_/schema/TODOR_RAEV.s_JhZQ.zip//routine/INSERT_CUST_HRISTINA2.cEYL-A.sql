create procedure insert_cust_hristina2 AS 
begin
    insert into customers2(customerid, firstName, age, city, salary)
    values (400, 'hristina55', 23, 'sofia', 2222);
end;
/

