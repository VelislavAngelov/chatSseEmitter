create PROCEDURE update_all_course_details (pk_id in int,name in varchar2, lecturer in varchar2,duration in int) AS
BEGIN
    update_course_name(pk_id , name );
    update_course_lecturer(pk_id , lecturer );
    update_course_duration(pk_id , duration );
END;
/

