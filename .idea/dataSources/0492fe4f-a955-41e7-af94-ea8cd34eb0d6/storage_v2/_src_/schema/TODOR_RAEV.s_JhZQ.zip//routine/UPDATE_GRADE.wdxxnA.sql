create PROCEDURE update_grade(pk_id in int, grade in int) AS
BEGIN
    update STUDENTS2  
    set STUDENTS2.grade=update_grade.grade 
    where STUDENTS2.PK_ID = update_grade.pk_id ;
END;
/

