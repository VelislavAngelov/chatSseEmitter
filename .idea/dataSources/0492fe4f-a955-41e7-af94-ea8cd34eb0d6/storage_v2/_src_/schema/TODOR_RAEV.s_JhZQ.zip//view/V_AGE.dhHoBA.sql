create view V_AGE as
select customerid, firstname, lastname, age from customers where city = 'London'
/

