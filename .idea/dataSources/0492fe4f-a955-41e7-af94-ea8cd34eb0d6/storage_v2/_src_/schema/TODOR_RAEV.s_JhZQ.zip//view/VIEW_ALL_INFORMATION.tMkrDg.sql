create view VIEW_ALL_INFORMATION as
select st.PK_ID,st.NAME,st.GRADE,cr.PK_ID,cr.NAME,cr.LECTURER,cr.DURATION
    from STUDENTS2 st right join  COURSES2 cr
    on st.PK_ID = cr.FK_ID
/

